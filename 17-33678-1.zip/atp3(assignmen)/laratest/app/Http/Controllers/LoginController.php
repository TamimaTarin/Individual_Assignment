<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\User;

class LoginController extends BaseController
{
	public function profile(){
        $allUser = User::all();
        return view('admin.ownprofile',['allUser'=>$allUser]);
    }
    public function index(){
    	return view('login.index');
    }
    public function verify(Request $req){
        $user = User::where('email',$req->email)
        ->where('password',$req->password)
        ->first();
        if($user != null){

            if($user->type=='admin'){

                $req->session()->put('email',$req->email);
                return redirect()->route('admin.index');
            }
            if($user->type=='manager'){
				
                //$req->session()->put('email',$req->email);
                //return redirect()->route('manager.index');
            }




            
        }
        else{
            $req->session()->flash('msg','invalid username/password');
            return redirect('/login');

        }
    }
	public function edit($id)
    {
        $user = User::where('id', $id)->first();

        return view('admin.editprofile', compact('user'));
    }

    public function update(Request $request, $id)
    {
        $user = User::find($id);
        $user->email =$request->email;        
        $user->password =$request->password;        
        $user->type =$request->type;
      
        $user->save();
        //return view('admin.index');
		$allUser = User::all();
        return view('admin.ownprofile',['allUser'=>$allUser]);

    }
}
