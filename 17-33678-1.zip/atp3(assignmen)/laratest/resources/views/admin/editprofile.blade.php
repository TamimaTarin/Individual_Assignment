<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="{{route('editprofile',['id' => $user->id])}}" method="post">
        {{csrf_field()}}
        <h3>editprofile </h3>
        <label for="id">id</label><br>
		<input type="text" name="id" readonly value="{{$user['id']}}"><br>
        <label for="">email</label><br>
        <input type="text" name="email" value="{{$user['email']}}" required><br>
        <label for="">password</label><br>
        <input type="text" name="password" value="{{$user['password']}}" required><br>
        <label for="">type</label><br>
        <input type="text" name="type" value="{{$user['type']}}" required><br>
        <button type="submit">Submit</button>
        
    </form>
</body>
</html>
