<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Bus Ticket Reservation System</h1>
	<!-- <form method="post"> -->
		<!-- <input type="hidden" name="_token" value="{{csrf_token()}}"> -->
		{{csrf_field()}}
		Hello to Bus Reservation System {{session('email')}}
		<!-- <br><a href="/logout">Logout</a>  -->
		<br><button id='logout' onclick="doRedirect()">Logout</button>
	</form>
</body>
<script type="text/javascript">
	function doRedirect(){
		window.location.replace("/logout");
	}

</script>
</html>