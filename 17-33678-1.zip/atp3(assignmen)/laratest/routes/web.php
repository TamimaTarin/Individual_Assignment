<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
    return view('welcome');
});

//Login Controller
Route::get('/login','LoginController@index');
Route::post('/login','LoginController@verify');


//Home Controller
Route::get('/home','HomeController@index')->name('home.index');



//Admin 
Route::get('/system/admin','AdminController@index')->name('admin.index');
Route::get('/system/buses/addschedule', 'ScheduleController@add')->name('addschedule');
Route::post('/system/buses/addschedule', 'ScheduleController@store')->name('addschedule');
Route::get('/system/viewbus', 'ScheduleController@index')->name('viewbus');
Route::get('/system/ownprofile', 'LoginController@profile')->name('ownprofile');
Route::get('/system/viewbus/{id}/editschedule', 'ScheduleController@edit')->name('editschedule');
Route::post('/system/viewbus/{id}/editschedule', 'ScheduleController@update')->name('editschedule');
Route::get('/system/viewbus{id}', 'ScheduleController@delete')->name('deleteschedule');
Route::get('/system/ownprofile/{id}/editprofile', 'LoginController@edit')->name('editprofile');
Route::post('/system/ownprofile/{id}/editprofile', 'LoginController@update')->name('editprofile');


//Logout Controller
Route::get('/logout', 'logoutController@index');