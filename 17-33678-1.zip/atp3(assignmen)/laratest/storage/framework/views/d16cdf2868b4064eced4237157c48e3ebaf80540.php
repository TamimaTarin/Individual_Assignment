<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>
    <br><h1><b>own profile</b></h1>
 
	<br><br><br>
	
	<table border="1">
		<tr>
		     <th>Id</th>
			<th>email</th>
			<th>password</th>
            <th>Type</th>
           <th>Action</th>
		</tr>

		<?php $__currentLoopData = $allUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		     <td><?php echo e($user['id']); ?></td>
			<td><?php echo e($user['email']); ?></td>
			<td><?php echo e($user['password']); ?></td>
			<td><?php echo e($user['type']); ?></td>
			<td>
                <a href="<?php echo e(route('editprofile', $user['id'])); ?>">Edit</a>
			</td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<a href="<?php echo e(route('admin.index')); ?>">Back</a>

</body>
</html>

<?php /**PATH C:\Users\USER\Desktop\atp3(assignmen)\laratest\resources\views/admin/ownprofile.blade.php ENDPATH**/ ?>