<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="<?php echo e(route('editschedule',['id' => $busschedule->id])); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3>Add Bus </h3>
        <label for="id">id</label><br>
		<input type="text" name="id" readonly value="<?php echo e($busschedule['id']); ?>"><br>
        <label for="">name</label><br>
        <input type="text" name="name" value="<?php echo e($busschedule['name']); ?>" required><br>
        <label for="">operator</label><br>
        <input type="text" name="operator" value="<?php echo e($busschedule['operator']); ?>" required><br>
        <label for="">Seat Row</label><br>
        <input type="number" name="seat_row" value="<?php echo e($busschedule['seat_row']); ?>" required><br>
        <label for="">Seat Column</label><br>
        <input type="number" name="seat_column" value="<?php echo e($busschedule['seat_column']); ?>" required><br>
        
        <label for="route">Route</label><br>
        <input type="text" name="route" value="<?php echo e($busschedule['route']); ?>" required><br>
        <label for="fare">Fare</label><br>
        <input type="text" name="fare" value="<?php echo e($busschedule['fare']); ?>" required><br>
        <label for="arrival">Arrival</label><br>
        <input type="time" name="arrival" value="<?php echo e($busschedule['arrival']); ?>" required><br>
        <label for="departure">Departure</label><br>
        <input type="time" name="departure" value="<?php echo e($busschedule['departure']); ?>" required><br>
        <button type="submit">Submit</button>
        
    </form>
</body>
</html>
<?php /**PATH C:\Users\USER\Desktop\atp3(assignmen)\laratest\resources\views/admin/editSchedule.blade.php ENDPATH**/ ?>