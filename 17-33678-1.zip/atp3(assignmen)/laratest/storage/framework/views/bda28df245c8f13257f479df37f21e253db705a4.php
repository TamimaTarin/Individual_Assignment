<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="<?php echo e(route('editprofile',['id' => $user->id])); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3>editprofile </h3>
        <label for="id">id</label><br>
		<input type="text" name="id" readonly value="<?php echo e($user['id']); ?>"><br>
        <label for="">email</label><br>
        <input type="text" name="email" value="<?php echo e($user['email']); ?>" required><br>
        <label for="">password</label><br>
        <input type="text" name="password" value="<?php echo e($user['password']); ?>" required><br>
        <label for="">type</label><br>
        <input type="text" name="type" value="<?php echo e($user['type']); ?>" required><br>
        <button type="submit">Submit</button>
        
    </form>
</body>
</html>
<?php /**PATH C:\Users\USER\Desktop\atp3(assignmen)\laratest\resources\views/admin/editprofile.blade.php ENDPATH**/ ?>