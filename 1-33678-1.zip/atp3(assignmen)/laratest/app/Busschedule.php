<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Busschedule extends Model
{
     public $timestamps = false;
}
