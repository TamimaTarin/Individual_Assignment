<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>welcome to admin homepage</h1>
	<!-- <form method="post"> -->
		<!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->
		<?php echo e(csrf_field()); ?>

		Hey <b><?php echo e(session('email')); ?></b>
		<br><a href="<?php echo e(route('ownprofile')); ?>">ownprofile</a>
    	<br><a href="<?php echo e(route('viewbus')); ?>">Show Bus Schedule</a>
    	<br><a href="<?php echo e(route('addschedule')); ?>">Add schdule</a>
		<!-- <br><a href="/logout">Logout</a>  -->
		<br><button id='logout' onclick="doRedirect()">Logout</button>
	</form>
</body>
<script type="text/javascript">
	function doRedirect(){
		window.location.replace("/logout");
	}

</script>
</html><?php /**PATH C:\Users\USER\Desktop\atp3(assignmen)\laratest\resources\views/admin/index.blade.php ENDPATH**/ ?>