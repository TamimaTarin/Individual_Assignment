<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>
    <br><h1><b>Bus Schedule</b></h1>
   <a href="<?php echo e(route('addschedule')); ?>">Add Schedule</a>
	<br><br><br>
	
	<table border="1">
		<tr>
		     <th>Id</th>
			<th>Name</th>
			<th>operator</th>
            <th>Seat Row</th>
            <th>Seat Column</th>
            <th>Route</th>
			<th>Fare</th>
			<th>Departure</th>
			<th>Arrival</th>
			<th>Action</th>
		</tr>

		<?php $__currentLoopData = $allBusschedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $busschedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		     <td><?php echo e($busschedule['id']); ?></td>
			<td><?php echo e($busschedule['name']); ?></td>
			<td><?php echo e($busschedule['operator']); ?></td>
			<td><?php echo e($busschedule['seat_row']); ?></td>
			<td><?php echo e($busschedule['seat_column']); ?></td>
			<td><?php echo e($busschedule['route']); ?></td>
			<td><?php echo e($busschedule['fare']); ?></td>
			<td><?php echo e($busschedule['arrival']); ?></td>
			<td><?php echo e($busschedule['departure']); ?></td>
			<td>
                <a href="<?php echo e(route('editschedule', $busschedule['id'])); ?>">Edit</a>
			</td>
			<td>
			    <a href="<?php echo e(route('deleteschedule', $busschedule['id'])); ?>">Delete</a>
                
			</td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<a href="<?php echo e(route('admin.index')); ?>">Back</a>

</body>
</html>

<?php /**PATH C:\Users\USER\Desktop\atp3(assignmen)\laratest\resources\views/admin/viewbus.blade.php ENDPATH**/ ?>